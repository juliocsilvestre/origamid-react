import React from 'react';

const App = () => {
  return <div>App React</div>;
};

export default App;
