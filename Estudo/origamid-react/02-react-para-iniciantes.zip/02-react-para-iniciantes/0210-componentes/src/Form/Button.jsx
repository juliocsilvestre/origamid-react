import React from 'react';

const Button = () => {
  return <button>Enviar</button>;
};

export default Button;
