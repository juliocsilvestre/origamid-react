import React from 'react';
import Title from './Title';
import './App.css';

const App = () => {
  return (
    <div className="container">
      <Title />
    </div>
  );
};

export default App;
