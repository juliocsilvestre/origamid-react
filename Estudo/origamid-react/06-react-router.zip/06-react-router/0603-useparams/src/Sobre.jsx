import React from 'react';

const Sobre = () => {
  return (
    <div>
      <h1>Sobre</h1>
      <p>Essa é a Sobre</p>
    </div>
  );
};

export default Sobre;
