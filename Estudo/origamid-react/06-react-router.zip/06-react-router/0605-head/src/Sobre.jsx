import React from 'react';
import Head from './Head';

const Sobre = () => {
  return (
    <div>
      <Head title="Sobre" description="Essa é a descrição da Sobre" />
      <h1>Sobre</h1>
      <p>Essa é a Sobre</p>
    </div>
  );
};

export default Sobre;
