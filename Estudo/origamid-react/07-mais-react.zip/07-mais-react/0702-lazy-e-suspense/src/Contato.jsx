import React from 'react';
import $ from 'jquery';

const Contato = () => {
  console.log($);
  return (
    <div>
      <h1>Contato</h1>
    </div>
  );
};

export default Contato;
